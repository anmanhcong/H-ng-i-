<ul class="dropdown-menu profile-arrow" role="menu" style="margin-top: 10px;">
	<li><a href="{{ route('user.editprofile') }}">Profile</a></li>
	<li><a href="{{url('admin/courseManage')}}">Admin manager</a></li>
	<li><a href="{{url('logout')}}">Logout</a></li>
</ul>