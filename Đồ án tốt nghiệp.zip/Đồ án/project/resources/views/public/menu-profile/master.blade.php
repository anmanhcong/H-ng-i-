<ul class="dropdown-menu pull-right profile-arrow" role="menu" style="margin-top: 10px;">
	<li><a href="{{ route('user.editprofile') }}">Profile</a></li>
	<li><a href="{{url('master/manage')}}">Manage page</a></li>
	<li><a href="{{url('logout')}}">Logout</a></li>
</ul>