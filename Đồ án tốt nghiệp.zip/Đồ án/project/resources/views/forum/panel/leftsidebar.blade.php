
<div class="col-md-3">
    <!-- Left column -->
    <a href="#"><strong><i class="glyphicon glyphicon-wrench"></i> Tools</strong></a>
    <ul class="nav nav-stacked left-sidebar">
        <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#manage">Manage <i class="glyphicon glyphicon-chevron-right"></i></a>
            <ul class="nav nav-stacked collapse" id="manage">
                <li class="active"> <a href="{{url('master/create-course')}}"><i class="glyphicon glyphicon-home"></i> Create Course</a></li>
                <li><a href="#"><i class="glyphicon glyphicon-envelope"></i> Messages <span class="badge badge-info">4</span></a></li>
                <li><a href="#"><i class="glyphicon glyphicon-cog"></i> Options</a></li>
                <li><a href="#"><i class="glyphicon glyphicon-off"></i> Logout</a></li>
            </ul>
        </li>
        <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2"> All <i class="glyphicon glyphicon-chevron-right"></i></a>
            <ul class="nav nav-stacked collapse" id="menu2">
                <li><a href="#">Topics</a></li>
                <li><a href="#">Replies</a>
                </li>
            </ul>
        </li>

    </ul>
</div>